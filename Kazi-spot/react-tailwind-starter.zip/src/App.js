function App() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-blue-500 text-white text-3xl">
      Hello, Tailwind + React!
    </div>
  );
}

export default App;
